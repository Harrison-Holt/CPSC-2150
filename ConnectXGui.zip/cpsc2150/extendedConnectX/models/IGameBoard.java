/*
 * Harrison S. Holt
 * Project 3- ConnectX
 * March 28, 2023
 */
package cpsc2150.extendedConnectX.models;

/**
 *
 * @Constraints:
 *       MIN_ROW <= self.row <= MAX_ROW
 *       MIN_COLUMN <= self.column <= MAX_COLUMN
 *       MIN_NUMTOWIN <= self.numToWin <= MAX_COLUMN
 */
public interface IGameBoard {

  int MIN_ROW = 3;
  int MAX_ROW = 100;
  int MIN_COLUMN = 3;
  int MAX_COLUMN = 100;
  int MIN_NUMTOWIN = 3;
  int MAX_NUMTOWIN = 25;
  int MIN_PLAYERS = 2;
  int MAX_PLAYERS = 10;

    /**
     * This method checks if a column is full or not.
     *
     * @param c the column position of the gameboard
     *
     * @return true if the column can accept another token.
     * false otherwise.
     *
     * @pre  0 <= c < MAX_COLUMN
     * @post Column = c AND game = #game AND
     *       checkTie if the game has any blank spaces on the gameboard 
     */
    public default boolean checkIfFree(int c)  {

       BoardPosition position = null;

       for (int i = 0; i < this.getNumRows(); i++) {

          position = new BoardPosition(i, c);

          // converts char to Character
          Character temp = Character.valueOf(whatsAtPos(position));

          // true if there is no character in that specific space
          if (temp.equals(' ')) {

             return true;
          }
       }
       return false;
    }

    /**
     * This method places the character p in column c. 
     *
     * @param p represents the character token that needs to be placed.
     * @param c the column position of the game board
     *
     * @pre 0 <= c < MAX_COLUMN AND [p is a valid character]
     *      AND checkFree(c) = true
     * @post Column = c AND game = #game AND
     *       [places token at c for player p]
     */
    public void placeToken(char p, int c);

    /**
     * This method checks to see if a player has won the game.
     *
     * @param c number of columns
     *
     * @return True if the last token placed in the column resulted in a win, false otherwise.
     *
     * @pre c > 0 [pos is the gameBoard position on the latest play]
     * @post Column = #c AND
     *        checkForWin iff [checkHorizWin equals true] OR
     *       [checkVertWin equals true] OR
     *       [checkDiagWin equals true] OR
     */
    public default boolean checkForWin(int c) {

       BoardPosition position = null;
       BoardPosition temp = null;
       char p = ' ';

       for (int i = 0; i < getNumRows(); i++) {

          temp = new BoardPosition(i, c);

          // Converts char to Character
          Character temp1 = Character.valueOf(whatsAtPos(temp));

          // Stops checking once there is available space spotted 
          if (temp1.equals(' ')) {

             position = new BoardPosition(i - 1, c);
             p = whatsAtPos(position);

             break;
          }

          // Stops checking once at end of the row 
          if (i == (getNumRows() - 1)) {

             position = new BoardPosition(i, c);
             p = whatsAtPos(position);

             break;
          }
       }
       if (checkHorizWin(position, p)) {

          return true;
       }
       if (checkVertWin(position, p)) {

          return true;
       }
       if (checkDiagWin(position, p)) {

          return true;
       }
       return false;
    }

    /**
     *  This method check to see if the game ended in a tie.
     *
     * @return True if the game is tied, false otherwise.
     *
     * @pre [game is not won]
     * @post checkTie iff game = [No blank spaces available]
     */
    public default boolean checkTie()  {

       BoardPosition pos = null;

       for (int i = 0; i < getNumColumns(); i++) {

          for (int j = 0; j < getNumRows(); j++) {

             pos = new BoardPosition(j, i);

             // converts char to Character
             Character temp = Character.valueOf(whatsAtPos(pos));

             // if there are any more available spaces on the gameboard 
             // return false, else true
             if (temp.equals(' ')) {

                return false;
             }
          }
       }
       return true;
    }

    /**
     * This method checks to see if a player has won horizontally.
     *
     * @param pos The row and column position of the board.
     * @param p The X and O tokens.
     *
     * @return true if a player has won horizontally, false otherwise.
     *
     * @pre 0 <= lastPos.getRow() < MAX_ROW AND 0 <= lastPos.getcolumn() < MAX_COLUMN
     *      AND [p is valid] AND [lastPos was the location where the last marker was placed in]
     *      AND [pos is within valid bounds] AND [pos is a position on the latest play]
     * @post gameBoard = #gameBoard AND [finds whether player p won a horizontal victory at pos]
     */
    public default boolean checkHorizWin(BoardPosition pos, char p) {

       int counter = 0;
       int r = pos.getRow();
       int c = pos.getColumn();
       BoardPosition temp;

       // Checks the position to the right
       while (true) {

          temp = new BoardPosition(r, c);
          Character temp1 = Character.valueOf(whatsAtPos(temp));

          // counter checks the tokens to the right
          if (temp1.equals(p)) {

             counter++;

             // make sure c does not go out of bounds
             if ((c + 1) < getNumRows()) {

                c++;
             }
             else {

                break;
             }
          }
          else {

             c = pos.getColumn();
             break;
          }
       }

       // checks to the left of position 
       counter--;

       while (true) {

          temp = new BoardPosition(r, c);
          Character temp1 = Character.valueOf(whatsAtPos(temp));

          // counter checks the tokens to the left
          if (temp1.equals(p)) {

             counter++;

             // makes sure c does not go out of bounds
             if ((c - 1) >= 0) {

                c--;
             }
             else {

                break;
             }
          }
          else {

             break;
          }
       }
       if (counter >= getNumToWin()) {

          return true;
       }
       return false;
    }

    /**
     * This method checks to see if a player has won vertically.
     *
     * @param pos The row and column position of the board.
     * @param p The X and O tokens.
     *
     * @return true if a player has won vertically, false otherwise.
     *
     * @pre pos > 0 AND [p is valid] AND 0 <= lastPos.getRow() < MAX_ROW AND
     *      0 <= lastPos.getcolumn() < MAX_COLUMN AND
     *      [lastPos was the location where the last marker was place in] AND
     *      [pos is within valid bounds] AND [pos is a position on the latest play]
     * @post checkVertWin iff [p equals 5 matching characters consecutively in a column]
     */
    public default boolean checkVertWin(BoardPosition pos, char p)  {

       //checks to see if the last token placed (which was placed in position pos by player p) resulted in 5 in a row vertically.
       //Returns true if it does, otherwise false
       int counter = 0;
       int r = pos.getRow();
       int c = pos.getColumn();
       BoardPosition temp;

       // Checks down from position 
       while (true) {

          temp = new BoardPosition(r, c);
          Character temp1 = Character.valueOf(whatsAtPos(temp));

          // counter checks the tokens from top to bottom
          if (temp1.equals(p)) {

             counter++;

             // makes sure r does not go out of bounds
             if ((r - 1) >= 0) {

                r--;
             }
             else {

                break;
             }
          }
          else {

             break;
          }
       }
       if (counter >= getNumToWin()) {

          return true;
       }
       else { 
         return false; 
      }
    }

    /**
     * This method checks to see if a player has won diagonally
     *
     * @param pos The row and column position of the board.
     * @param p The X and O tokens.
     *
     * @return true if a player has won diagonally, false otherwise.
     *
     * @pre pos > 0 AND [p is valid] AND [pos is a position on the latest play] AND
     *      [pos is within valid bounds]
     * @post gameBoard = #gameBoard AND
     *       checkDiagWin iff [p matches 5 in a row going in a positive slope OR
     *                         5 in a row going in a negative slope]
     */
    public default boolean checkDiagWin(BoardPosition pos, char p) {

       int counter1 = 1;
       int counter2 = 1;
       int r = pos.getRow();
       int c = pos.getColumn();
       BoardPosition temp = null;

       //checks up and to the right
       counter1--;

       while(true) {

          temp = new BoardPosition(r, c);
          Character temp1 = Character.valueOf(whatsAtPos(temp));

          if(temp1.equals(p)) {

             counter1++;

             //makes sure r does not go out of bounds
             if((r + 1) < getNumRows()) {

                r++;
             }
             else {

                break;
             }

             //makes sure c does not go out of bounds
             if((c + 1) < getNumColumns()) {
                c++;
             }
             else {

                break;
             }
          }
          else {

             break;
          }
       }
       r = pos.getRow();
       c = pos.getColumn();

       //checks up and to the left
       counter2--;

       while(true) {

          temp = new BoardPosition(r, c);
          Character temp1 = Character.valueOf(whatsAtPos(temp));

          if(temp1.equals(p)) {

             counter2++;

             //makes sure r does not go out of bounds
             if((r + 1) < getNumRows()) {

                r++;
             }
             else {

                break;
             }

             //makes sure c does not go out of bounds
             if((c - 1) >= 0) {

                c--;
             }
             else {

                break;
             }
          }
          else {

             break;
          }
       }

       r = pos.getRow();
       c = pos.getColumn();

       //checks down and to the left
       counter1--;

       while(true) {

          temp = new BoardPosition(r, c);
          Character temp1 = Character.valueOf(whatsAtPos(temp));

          if(temp1.equals(p)) {

             counter1++;
             //makes sure r does not go out of bounds

             if((r - 1) >= 0) {

                r--;
             }
             else {

                break;
             }

             //makes sure c does not go out of bounds
             if((c - 1) >= 0) {

                c--;
             }
             else {

                break;
             }
          }
          else {

             break;
          }
       }
       r = pos.getRow();
       c = pos.getColumn();

       //checks down and to the right
       counter2--;

       while(true) {

          temp = new BoardPosition(r, c);
          Character temp1 = Character.valueOf(whatsAtPos(temp));

          if(temp1.equals(p)) {

             counter2++;

             //makes sure r does not go out of bounds
             if((r - 1) >= 0) {

                r--;
             }
             else {

                break;
             }

             //makes sure c does not go out of bounds
             if((c + 1) < getNumColumns()) {

                c++;
             }
             else {

                break;
             }
          }
          else {

             break;
          }
       }
       r = pos.getRow();
       c = pos.getColumn();

       if((counter1 >= getNumToWin()) || (counter2 >= getNumToWin())) {

          return true;
       }
       else {

          return false;
       }
    }

    /**
     * This method the token ("", X, O) that is at the Row and Column position
     *
     * @param pos The row and column position of the board.
     *
     * @return the character that is at the current game board position.
     *
     * @pre [pos is within valid bounds]
     * @post whatsAtPos = [character at pos (' ' or game token)] AND
     *       GameBoard = #GameBoard
     */
    public char whatsAtPos(BoardPosition pos);

    /**
     * This method checks to see if a player is at a designated position.
     *
     * @param pos the row and column the player is currently at.
     * @param player represents the game X and O tokens.
     *
     * @return True if the player is at the desired position, false otherwise.
     *
     * @pre [pos is within valid bounds] AND [player is valid]
     * @post isPlayerAtPos = [true if char at pos is player, false otherwise]
     *
     */
    public default boolean isPlayerAtPos(BoardPosition pos, char player) {

      if (whatsAtPos(pos) == player) {
         
         return true;
      }
      return false;
    }

    /** 
     * This method returns the number of rows 
     *
     * @return number of rows
     *
     * @post getNumRows = [number to rows]
     */
    public int getNumRows();

    /** 
     *  This method returns the number of columns
     *
     * @return number of columns
     *
     * @post getNumColumns = [number of columns]
     */
    public int getNumColumns();

    /**
     *
     * @return number to win
     *
     * @post getNumToWin = [number to win]
     */
    public int getNumToWin();
}