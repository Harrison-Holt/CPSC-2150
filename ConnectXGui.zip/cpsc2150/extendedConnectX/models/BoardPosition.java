/*
 * Harrison S. Holt
 * Project 3- ConnectX
 * March 28, 2023
 */
package cpsc2150.extendedConnectX.models;

/**
 * This class is used to store information about columns and row
 */
public class BoardPosition {
    /**
     * @invariant Row >= 3 AND Row <= 100 AND Column >= 3 AND Column <= 100 
     *
     */

    private int row;
    private int column;


    /**
     * This method creates a game board with the specified column and row.
     *
     * @param r number of rows the board has
     * @param c number of columns the board has
     *
     *
     * @pre r >= 3 AND  <= 100 AND c >= 3 AND c <= 100 
     * @post Row = r AND Column = c
     */
    public BoardPosition(int r, int c) {

        row = r;
        column = c;
    }

    /**
     * This method gets the value of the Row.
     *
     * @post getRow = Row and
     *       Row = #Row and
     *       Column = #Column
     */
    public int getRow() {

        //returns the row number 
        return row;
    }

    /**
     * This method gets the value of the Column.
     *
     * @post getColumn = Column and
     *       Row = #Row and
     *       Column = #Column
     */
    public int getColumn() {

        //returns the column number 
        return column;
    }

    /**
     * This method compares the equality of the two BoardPositions
     *
     * @return true if BoardPosition is equal to the other BoardPosition, false otherwise.
     *
     * @post true if BoardPosition is equal to the other BoardPosition, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {

        // checks to see if both objects are not equal
        if (obj.getClass() != getClass()) {

            return false;
        }
        BoardPosition pos = (BoardPosition) obj;

        // returns if both of the objects are equal
        return (pos.getRow() == getRow() && pos.getColumn() == getColumn());
    }

    /**
     * This method overrides the default implementation of {@code toString} to provide
     * a string representation of the coordinates of the row and column.
     *
     * @return a string representation of the Board positions
     *
     * @post toString = "[row], [column]"
     */
    @Override
    public String toString() {

        String s = row + "," + column;
        return s;
    }

}
